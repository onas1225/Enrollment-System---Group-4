﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enrollment_Form___Group_4
{
    public partial class Form7 : Form
    {
        public Form7(string strand, string firstName, string middleName, string lastName, string sex, DateTime birthday,
                 string studentNumber, string placeOfBirth, string religion, int age,
                 string motherName, string motherNumber, string motherOccupation,
                 string fatherName, string fatherNumber, string fatherOccupation,
                 bool birthCert, bool reportCard, bool picture, string previousSchool)
        {
            InitializeComponent();

            Strand.Text = strand;
            FirstNameTxtBox.Text = firstName;
            MiddleNameTxtBox.Text = middleName;
            LastNameTxtBox.Text = lastName;

            if (sex == "Male") Male.Checked = true;
            else Female.Checked = true;

            Birthday.Value = birthday;
            StudentNum.Text = studentNumber;
            PlaceofBirth.Text = placeOfBirth;
            Religion.Text = religion;
            Age.Text = age.ToString();

            textBox1.Text = motherName;
            textBox2.Text = motherNumber;
            textBox3.Text = motherOccupation;
            textBox4.Text = fatherName;
            textBox5.Text = fatherNumber;
            textBox6.Text = fatherOccupation;

            BirthCerti.Checked = birthCert;
            ReportCard.Checked = reportCard;
            twobytwopic.Checked = picture;

            PreviousScho.Text = previousSchool;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 adminForm = new Form6();
            adminForm.Show();
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            string query = "UPDATE enrollment SET " +
                "Strand = @Strand, FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, " +
                "Sex = @Sex, Birthday = @Birthday, StudentNumber = @StudentNumber, PlaceOfBirth = @PlaceOfBirth, " +
                "Religion = @Religion, Age = @Age, MotherFullName = @MotherFullName, MotherNumber = @MotherNumber, " +
                "MotherOccupation = @MotherOccupation, FatherFullName = @FatherFullName, FatherNumber = @FatherNumber, " +
                "FatherOccupation = @FatherOccupation, BirthCertificate = @BirthCertificate, ReportCard = @ReportCard, " +
                "TwoByTwoPicture = @TwoByTwoPicture, PreviousSchool = @PreviousSchool " +
                "WHERE StudentNumber = @StudentNumber";

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-CVS0J8H\\SQLEXPRESS;Initial Catalog=enrollment;Integrated Security=True;TrustServerCertificate=True"))
            {
                conn.Open();

                using (SqlCommand updateCommand = new SqlCommand(query, conn))
                {
                    updateCommand.Parameters.AddWithValue("@Strand", Strand.Text);
                    updateCommand.Parameters.AddWithValue("@FirstName", FirstNameTxtBox.Text);
                    updateCommand.Parameters.AddWithValue("@MiddleName", MiddleNameTxtBox.Text);
                    updateCommand.Parameters.AddWithValue("@LastName", LastNameTxtBox.Text);
                    updateCommand.Parameters.AddWithValue("@Sex", Male.Checked ? "Male" : "Female");
                    updateCommand.Parameters.AddWithValue("@Birthday", Birthday.Value);
                    updateCommand.Parameters.AddWithValue("@StudentNumber", StudentNum.Text);
                    updateCommand.Parameters.AddWithValue("@PlaceOfBirth", PlaceofBirth.Text);
                    updateCommand.Parameters.AddWithValue("@Religion", Religion.Text);
                    updateCommand.Parameters.AddWithValue("@Age", int.Parse(Age.Text));

                    updateCommand.Parameters.AddWithValue("@MotherFullName", textBox1.Text);
                    updateCommand.Parameters.AddWithValue("@MotherNumber", textBox2.Text);
                    updateCommand.Parameters.AddWithValue("@MotherOccupation", textBox3.Text);
                    updateCommand.Parameters.AddWithValue("@FatherFullName", textBox4.Text);
                    updateCommand.Parameters.AddWithValue("@FatherNumber", textBox5.Text);
                    updateCommand.Parameters.AddWithValue("@FatherOccupation", textBox6.Text);

                    updateCommand.Parameters.AddWithValue("@BirthCertificate", BirthCerti.Checked);
                    updateCommand.Parameters.AddWithValue("@ReportCard", ReportCard.Checked);
                    updateCommand.Parameters.AddWithValue("@TwoByTwoPicture", twobytwopic.Checked);

                    updateCommand.Parameters.AddWithValue("@PreviousSchool", PreviousScho.Text);

                    updateCommand.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Student record updated successfully!");
            this.Close();
        }
    }
}